import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";

import UserBookings from "./pages/UserBookings";
import AdminDashboard from "./pages/AdminDashboard";
import OperatorDashboard from "./pages/OperatorDashboard";

function App() {
  return (
    <BrowserRouter>
      <Routes>

        <Route path="/" element={<Home/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path="/signup" element={<Signup/>}/>

        {/* dashboards */}
        <Route path="/bookings" element={<UserBookings/>}/>
        <Route path="/admin" element={<AdminDashboard/>}/>
        <Route path="/operator" element={<OperatorDashboard/>}/>

      </Routes>
    </BrowserRouter>
  );
}

export default App;
