import Navbar from "../components/Navbar";

export default function AdminDashboard(){
  return (
    <div>
      <Navbar/>
      <h2 style={{padding:40}}>Admin dashboard</h2>
    </div>
  );
}
