import React, { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import Navbar from "../components/Navbar";
import "./Login.css";

function Login() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post(
        "http://localhost:5000/api/auth/login",
        { email, password }
      );

      const { role, user } = response.data;

      // ✅ Save login info
      localStorage.setItem("user", JSON.stringify(user));
      localStorage.setItem("role", role);

      alert("Login successful");

      // ✅ Redirect by role
      if (role === "admin") {
        navigate("/admin");
      }
      else if (role === "operator") {
        navigate("/operator");
      }
      else {
        navigate("/bookings");   // normal user
      }

    } catch (error) {
      alert(error.response?.data?.message || "Login failed");
    }
  };

  return (
    <div>

      <Navbar />

      <div className="login-page">

        <div className="login-card">

          <h2>Login</h2>

          <form onSubmit={handleLogin}>

            <input
              type="email"
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            <button type="submit">Sign in</button>

            {/* REGISTER LINK */}
            <p className="register-text">
              New user? <Link to="/signup">Register Now</Link>
            </p>

          </form>

        </div>

      </div>

    </div>
  );
}

export default Login;
