import Navbar from "../components/Navbar";

export default function OperatorDashboard(){
  return (
    <div>
      <Navbar/>
      <h2 style={{padding:40}}>Operator dashboard</h2>
    </div>
  );
}
