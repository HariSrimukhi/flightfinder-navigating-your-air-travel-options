import { useEffect, useState } from "react";
import axios from "axios";
import Navbar from "../components/Navbar";
import "./UserBookings.css";

export default function UserBookings() {

  const [bookings, setBookings] = useState([]);

  // load bookings on page open
  useEffect(() => {
    fetchBookings();
  }, []);

const fetchBookings = async () => {
  try {

    const user = JSON.parse(localStorage.getItem("user"));

    const res = await axios.get(
      `http://localhost:5000/api/bookings/user/${user._id}`
    );

    setBookings(res.data);

  } catch (err) {
    console.error(err);
    alert("Failed to load bookings");
  }
};


  const cancelBooking = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/bookings/${id}`);
      alert("Ticket cancelled");
      fetchBookings(); // reload
    } catch (err) {
      console.error(err);
      alert("Cancel failed");
    }
  };

  return (
    <div>

      <Navbar />

      <div style={{padding:"40px"}}>

        <h2 style={{marginBottom:"25px"}}>My Bookings</h2>

        {bookings.length === 0 && <p>No bookings yet</p>}

       {bookings.map(b => (

  <div key={b._id} className="booking-card">

    <h3>{b.airline}</h3>

    <p><strong>{b.from}</strong> → <strong>{b.to}</strong></p>

    <p>Price: ₹{b.price}</p>

    <p className="booking-date">
      Booked on: {new Date(b.createdAt).toLocaleDateString()}
    </p>

    <button onClick={() => cancelBooking(b._id)}>
      Cancel Ticket
    </button>

  </div>

))}


      </div>

    </div>
  );
}
