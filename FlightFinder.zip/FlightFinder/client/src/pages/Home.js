import { useState } from "react";
import axios from "axios";
import "./Home.css";

export default function Home() {

  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [date, setDate] = useState("");
  const [flights, setFlights] = useState([]);

  // 🔎 SEARCH FLIGHTS
  const searchFlights = async () => {

    if (!from || !to || !date) {
      alert("Please select departure, destination and date");
      return;
    }

    try {
      const res = await axios.get(
        `http://localhost:5000/api/flights/search?from=${from}&to=${to}`
      );
      setFlights(res.data);
    } catch (err) {
      console.error(err);
      alert("Search failed");
    }
  };

  // ✈️ BOOK FLIGHT  ✅ MUST BE HERE (NOT IN JSX)
const bookFlight = async (flight) => {
  try {

    const user = JSON.parse(localStorage.getItem("user"));

    const res = await axios.post(
      "http://localhost:5000/api/bookings",
      {
        userId: user._id,     // ✅ important
        flightId: flight._id,
        airline: flight.airline,
        from: flight.from,
        to: flight.to,
        price: flight.price
      }
    );

    alert(res.data.message);

  } catch (err) {
    console.error(err);
    alert("Booking failed");
  }
};


  return (
    <div className="home-container">

      {/* ===== NAVBAR ===== */}
      <div className="navbar">
        <div className="logo">✈ SB Flights</div>

        <div className="nav-links">
          <a href="/">Home</a>
          <a href="/login">Login</a>
        </div>
      </div>


      {/* ===== HERO ===== */}
      <div className="hero">

        <h1>Embark on an Extraordinary Flight Booking Adventure!</h1>

        <p>
          Unleash your travel desires and book extraordinary flight journeys
          that will transport you to unforgettable destinations.
        </p>

        {/* SEARCH BOX */}
        <div className="search-box">

          <select onChange={e => setFrom(e.target.value)}>
            <option value="">Departure City</option>
            <option>Hyderabad</option>
            <option>Delhi</option>
            <option>Mumbai</option>
            <option>Chennai</option>
            <option>Bangalore</option>
          </select>

          <select onChange={e => setTo(e.target.value)}>
            <option value="">Destination City</option>
            <option>Hyderabad</option>
            <option>Delhi</option>
            <option>Mumbai</option>
            <option>Chennai</option>
            <option>Bangalore</option>
          </select>

          <input type="date" onChange={e => setDate(e.target.value)} />

          <button onClick={searchFlights}>Search</button>

        </div>

      </div>


      {/* ===== RESULTS ===== */}
      <div className="results">

        {flights.map(f => (
          <div key={f._id} className="card">

            <h3>{f.airline}</h3>
            <p>{f.from} → {f.to}</p>
            <p>{f.departureTime} - {f.arrivalTime}</p>
            <p>₹{f.price}</p>

            {/* BOOK BUTTON */}
            <button onClick={() => bookFlight(f)}>
              Book Now
            </button>

          </div>
        ))}

      </div>

    </div>
  );
}
