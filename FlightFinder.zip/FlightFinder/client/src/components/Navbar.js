import { Link } from "react-router-dom";
import "./Navbar.css";

export default function Navbar() {
  return (
    <div className="navbar">
      <div className="nav-left">
        <span className="plane">✈</span>
        <span className="brand">SB Flights</span>
      </div>

      <div className="nav-right">
        <Link to="/">Home</Link>
        <Link to="/login">Login</Link>
        <button onClick={handleLogout} className="logout-btn">
  Logout
</button>
      </div>
    </div>
  );
}
const handleLogout = () => {
  localStorage.removeItem("user");
  window.location.href = "/login";
};

