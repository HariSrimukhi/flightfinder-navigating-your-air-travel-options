const express = require("express");
const Flight = require("../models/Flight");

const router = express.Router();

// Add Flight (for testing)
router.post("/add", async (req, res) => {
  try {
    const flight = new Flight(req.body);
    await flight.save();
    res.status(201).json({ message: "Flight added successfully ✅" });
  } catch (error) {
    res.status(500).json({ message: "Error adding flight", error });
  }
});

// Get All Flights
router.get("/", async (req, res) => {
  try {
    const flights = await Flight.find();
    res.status(200).json(flights);
  } catch (error) {
    res.status(500).json({ message: "Error fetching flights", error });
  }
});

// Search Flights
router.get("/search", async (req, res) => {
  try {
    const { from, to } = req.query;

    const flights = await Flight.find({
      from: from,
      to: to
    });

    res.json(flights);
  } catch (error) {
    res.status(500).json({ message: "Error fetching flights" });
  }
});

module.exports = router;
